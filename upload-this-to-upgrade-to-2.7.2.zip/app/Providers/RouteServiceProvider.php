<?php //00391
// Foodomaa� Copyright � StackCanyon Technologies LLP - All Rights Reserved.
echo('<html> <style type="text/css"> <!-- body { font-family: Arial, Helvetica, sans-serif; font-size: 14px; text-decoration: none; text-align: center; background-color: #fafafa; } div#container { margin-top: 4rem; margin-left: auto; margin-right: auto; width: 550px; text-align: center; padding: 2rem; background-color: #fff; border-radius: 8px; box-shadow: rgba(0, 0, 0, 0.05) 0px 4px 12px; } --> </style> <title>Missing PHP Extension</title> <body> <div id="container"> <h2 align="center">Missing PHP Extension</h2> <p>ionCube Loader PHP extension is either not enabled or not installed on your server.</p>  <p> <a href="https://docs.foodomaa.com/extras/requirements-for-foodomaa#how-to-enable-php-extensions" target="_blank">Click Here</a> to learn how to enable PHP Extensions. </p></div></body> </html>');exit(199);

?>
HR+cPvWJAKnV/f5Z9gIyRxE24gLZ/80cG/8UdDYsFuV+lWgYXGNwoR+LCS4QN84T5N0fq/JksZ0t
pxasL8pDXBw0PlT6V58a9uw1x+cPLAORipRitF0NlerGj5RHBhE7ySana+1d37xeVfCat+4V47ID
iXsOcux3lc3lrJz4CgGCTnL7GPSnespfu58X1HpVV+oajb8smIxVq8lJ5gRJSocuMPx2CkFy3h21
W1FACrMBWzvhlhJoBRixe813+KY6Wxq2WeX2Sg8GGcdrh4O0e/u/0d6M0GlgQJ+P6Wdu09BgZxpr
Lhf5E/+fwtMViF9nK4+F9y913ZcBMXIIzGAeywnJbQJg4UtUXErmTbbTGu873DiLAkazuuxtq6Vk
9zkqhmyaksECfIGPLi7ptb6Rq5NGXarQS2mKBtZ4ku5TpuvcgS4WOaYjSq4WpyUDgsS/+OblStgq
6hczOH+nbML81/CrPmDedkusOsnr/xa9QWlgh11FkvapOCIDvP0YB/jyRiL/gThT4kCbQ04ol2Gd
imzzfeGse8jxMaPL7rSk26pu4L9qdUnkyXiCY+t4Opuiw9B+PbKAXKzrWxGYXqn9KbMLZCWM8W/r
Ff6kL5BoHDgNEvbMddYJixQLs5XpX9EYhWd/QhP02XPUwAE75/z/A3cmpmwkiY9q2OJTHU9tqNrv
rBZPoTX8hA69bPis1CHq98qkPzuDmmeuxsF/nsf8xBYZECz/qE3Z2AKhCUAFH9DKx2puVgrMFeJU
/XnPrNDX8XIUKD1fsFXRAfrGlFyP2csCGLZgE3F3Mcp4scwEkK+IAN0c3SJG/YE8E1KTZ1SgfcRJ
EDn08nYXGWAVetNmcBEU9nBeykIThVyuegtIEgBZc+Ubxtha8FxQx+kqlJYchQqWRdSn091LGMx2
uyjNMba+tqEHm8d4KLOssyS1iLtMbzPdj+vSyKpr8Gtv/HA7CJcUEJiMkaL6K6t99UwRrT95UuUa
iFfADIjV2mREeRS2x945ab1buA2hLSZR4W+sE0kEDXdQ270c6N9wjTk6UGyovl43gQfQfL5Vl/fm
olWcDqtRHx9uUzAT7Xlo6tUuvqzhRGQtShsbBHPfs+WI2gg81XQ4Ralo6cKT4ANBJ5GsP76gMS4d
dDSSXVD+D/LLgiUK3mjqR9lz63gNSZAaxDu462UMwi/mJv0tVsHLMhfQHDnXn1lKCMBtBvPMDVkd
55ydoDSqtpW9AToKHh5XpfNf1pxyMxDdIygHAl/MmDg4Ve5Tv2WTUruQUc26JNOm2/MaHMrwDEHF
05WjRLG53/ioj/Evhh6gkO7c1lRS7xR9kWcU3FKn7c8knXaVUDgRSgXYIBbRKHkrMUVClVh7fK6M
BfxfrwEuoqKXJSEWMzBBY0v3VoozkBqFOG29rufjra33WoYiffvGzKPA8bVgMfI0edy+DtaFfaCV
eHJJv0VkYEsdBjTapbv2bSTSFbwjw1sE2RS6aIylMDhBccUDQUeNLFdhVAhPGp2L2ez+5jbBYrYR
eo+CEef29Du4A+SKrZJnFG5yBAo4pLpFs/yspwP4R3zgzAjiqpQIDWzMqRJv3PajvWEVhieTmkP0
GxoNIhT6M/qzOUIj3Livv6LEC4ia0tv2MHJsZ+7rx0LZUIxk9ghkfFgE1AhO4rfi6cP68pXNTra2
wUMoMKvzHbVKb6G8urOsy8+eb/xZgjNg2XFkQyBJexOHLUwiEnG274FDyL7sojl4EHeiM3bhzWV8
CpdajgjpFWXDk+Qzti3iC8XawROm7sNd81CgCX4rw6bTU3z3WORe5YkH5fvYxlqObzqipmfMpswe
WXtJ12OAlPw/NlON5y8W7d1X+TZUlbhVNLgHua8Gb/3Gcf8jL9m/wcSfC8ZISqsFcfPqqNJl+Sdh
zvirI4PPb7ri6uZ9m2bkd1GchKtTReTcVFf9WkP16Y0I9V3NGB7VbmTp7/EahQfFTUPTAUiBskHT
ymoECFg20RgBNQqwmf1Gwr3s0t3lnU2H55GIqvQFAGx3tybBlqqT7s+gbLMdFcJ/WGfJx323dXUR
XyqYDin4yGd95XENuRbZVa9DKzfKcvVbSrD8TyX4i6N3k/1QsDSE9S2rOeqiRJ6NkVtd68K5n3jE
OUJO8R4Xe4VG29oopiIK67HiulqNRUDvTosMm2e/wzAZdwGIcrmYHEcEGpzYLn7zCFwZrCT51J+p
xU1ck87ccRtSsqDOSZA7innLBsH0mCLmIdCkaSWVdLR0106VHKkg0OsiW6P0bATuBoUacD4zdFdH
vqxKtukulQLDAMyCsbjl0aapRabye6y477Qr5yAbchE6EkUPcd+eXMXPR4u73CM4VuYxeYBqUk08
koFDcmkQEiJsl3gD/pAa08grJghCB04Ykkgwx10jai+qneuX90C3CvEnPR/IMKOfwIaOvT3jNXrH
UyesW13sCvjv10JjpIta116t6NRvTY9x/C+JHWIDtkGu0tkRed+jOAq6KckQpoOwev4q8HcYKh7l
TEWV+RyrC6zdiQJfOeW6A3PuVKsA/cUuViHPwTBy15IyO+HUNrnafD+249Dv/rijOC3nL/WKMa89
vXLHVAXCCG7XAURQ3fqosfaOFRKMK8/b