<?php if(Session::has('success')): ?>
<script>
    $(function () {
        $.jGrowl("<?php echo e(Session::get('success')); ?>", {
            position: 'bottom-center',
            <?php if(auth()->check() && auth()->user()->hasRole("Store Owner")): ?>
            header:  '<?php echo e(__('storeDashboard.successNotification')); ?>',
            <?php else: ?>
            header: 'SUCCESS 👌',
            <?php endif; ?>
            theme: 'bg-success',
        });    
    });
</script>
<?php endif; ?>
<?php if(Session::has('message')): ?>
<script>
    $(function () {
        $.jGrowl("<?php echo e(Session::get('message')); ?>", {
            position: 'bottom-center',
            <?php if(auth()->check() && auth()->user()->hasRole("Store Owner")): ?>
            header:  '<?php echo e(__('storeDashboard.woopssNotification')); ?>',
            <?php else: ?>
            header: 'Wooopsss ⚠️',
            <?php endif; ?>
            theme: 'bg-warning',
        });    
    });
</script>
<?php endif; ?>
<?php if($errors->any()): ?>
<script>
    $(function () {
        $.jGrowl("<?php echo e(implode('', $errors->all(':message'))); ?>", {
            position: 'bottom-center',
            header: 'ERROR ⁉️',
            theme: 'bg-danger',
        });    
    });
</script>
<?php endif; ?>

<?php if(session()->get('elflag')): ?>
<script>
    $(function () {
        alert("<?php echo e(base64_decode("WW91IGRvIG5vdCBoYXZlIGFuIEV4dGVuZGVkIExpY2Vuc2UgdG8gZGVwbG95IHRoZSBSZWFjdEpzIG1vZGlmaWNhdGlvbnMuIEFsbCB0aGUgbW9kaWZpZWQgZmlsZXMgaGF2ZSBiZWVuIHJlbW92ZWQuIEtpbmRseSByZXZlcnQgYmFjayB0byB0aGUgb3JpZ2luYWwgZnJvbnRlbmQgZmlsZXMu")); ?>")
    });
</script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\foodomaa\resources\views/admin/includes/notification.blade.php ENDPATH**/ ?>